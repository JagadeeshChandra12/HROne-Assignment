# Employee Attendance & Analytics API

FastAPI + PyMongo service implementing the full contract in `openapi.yaml` (business rules R1-R10) over the
data model in `DATA_MODEL.md`. All application code lives in `app/main.py`.

## Setup

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Configuration

Two environment variables, read at startup (a local `.env` is loaded for convenience, but real environment
variables always take priority):

| Variable | Default | Purpose |
|---|---|---|
| `MONGO_URI` | `mongodb://localhost:27017` | MongoDB connection string |
| `MONGO_DB` | `attendance_db` | Database name |

## Run

```bash
python sample_seed.py            # optional: loads the nine sample documents from sample_data/
uvicorn app.main:app --port 8000
```

`GET /health` returns 200 once MongoDB answers a ping. All required indexes are created idempotently on
startup (see `DECISIONS.md` for which ones and why).

## Status

All endpoints in `openapi.yaml` are implemented: employees (create/list), punch-in, punch-out, attendance
listing, regularization, the three analytics aggregations (employee monthly, department summary, late
leaderboard, department trend), and `GET /admin/explain/{endpoint}`.

Verified locally against MongoDB 7 (Docker): the nine sample documents reproduce the worked examples in
`DATA_MODEL.md` exactly (work hours, late/overtime minutes, half-day, overnight shift, regularization
history); concurrent punch-in/punch-out/employee-creation races each yield exactly one success and 409s for
the rest; all five `/admin/explain/...` queries report an `IXSCAN` and no `COLLSCAN`. See `REVIEW.md` for
starter-code defects found and fixed, and `DECISIONS.md` for index choices and design trade-offs.

**Known limitation:** correctness was checked by hand against the sample dataset and additional manual
test cases (ties, zero-log employees, mid-month/future joiners, overnight shifts, weekends, missing
weekdays) — not against the grader's hidden ~100k-record dataset.
